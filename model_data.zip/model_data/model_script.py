# -*- coding: utf-8 -*-
"""
Created on Tue Sep 14 11:10:44 2021

@author: ernpsaa
"""

# -*- coding: utf-8 -*-
"""
Created on Tue May 11 13:06:00 2021

@author: etaacph
"""

# Importing necessary packages
# from enum import unique
import os
# import json
import warnings
warnings.filterwarnings("ignore")

# For file handling
import pandas as pd

# For numerical calculation
import numpy as np

#For Regular Expression
import re, string, unicodedata

from datetime import datetime
# datetime object containing current date and time

# For NLP
import nltk
nltk.download('words')
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
eng_words = set(nltk.corpus.words.words())
stop_words = set(stopwords.words("english")) 

from nltk.stem import PorterStemmer, WordNetLemmatizer
lem = WordNetLemmatizer()



from sklearn.feature_extraction.text import TfidfVectorizer

from sklearn.metrics import accuracy_score


import math

from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn import model_selection

# Ensemble's
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.calibration import CalibratedClassifierCV
import pickle




# from sklearn.model_selection import RepeatedKFold
        

class EnsembleVotedModel:
    def __init__(self, df, features, target, modelpath, TFIDF_path):
        """
        Replace below code while reading dataframe instead of file
        
        datafile = config["Path_To_CSV_File"] 
        if ".csv" in datafile:
            self.dataset = pd.read_csv(datafile)
        elif ".xlsx" in datafile:
            self.dataset = pd.read_csv(datafile, engine="openpyxl")

        """
        self.features = features
        self.target = target
        self.dataset = df
        self.model_path = modelpath
        self.TFIDF_path = TFIDF_path


    def cleaning_text(self, text):
        """
        Subfunction of data preprocessing
        """
        stop = set(stopwords.words("english"))
        text = text.lower()
        text= re.sub('[^A-Za-z]+',' ' ,text)
        text = re.sub(r'http\S+',' ', text)
        text = " ".join([word for word in text.split() if (word not in stop) and len(word)>1]) #remove stop words and small words
        # print(text)
        return text

    def preprocess(self, tempdf):
        """
        It will preprocess the dataset
        """
        
        tempdf = tempdf.dropna()
        tempdf =  tempdf.drop_duplicates()
        tempdf =  tempdf.reset_index(drop=True)
        
        return tempdf


    def data_generation(self,dataset):
        """
        Prepare the data for Model Engineering
        """
        dataset = self.preprocess(dataset) 
        dataset["Action"] = dataset[self.features]
        if len(self.features) >1:
            for i in range(len(self.features)-1):
                dataset["Action"] = dataset["Action"].str.strip() + " " + dataset[self.features[i+1]].str.strip()
                
        # print(dataset["Action"][0])
        
        dataset["Action"] = dataset["Action"].apply(lambda x:self.cleaning_text(x))
        print(dataset["Action"][0])
        return dataset



    def TF_IDF_Vectorization(self):
        """
        Converting the Text Data into Integer to feed to Model
        """

        dataset = self.data_generation(self.dataset)

        # print(dataset['Action'][0])
        #mindf = 0.1% max_df = 0.2/0.8
        tfidfVector = TfidfVectorizer(max_features=10000,stop_words=stopwords.words('english'),use_idf=True,ngram_range=(1, 3))

        features = tfidfVector.fit_transform(dataset["Action"]).toarray()
        #labels = dataset.Category_ID
        labels = dataset[self.target]
        print("\n The shape of features generated from TF-IDF is : ",features.shape)

        # tfidf_filename = os.path.join(self.TFIDF_path, "TF_IDF_" + str(datetime.now().strftime("%Y_%m_%d_%H_%M_%S")) + ".pickle")
        tfidf_filename = os.path.join(self.TFIDF_path, "TF_IDF.pickle")
        
        with open(tfidf_filename, 'wb') as file:
            pickle.dump(tfidfVector, file)

        return features, labels, tfidf_filename

    def Modelt_Training(self):
        """
        Model Training on final dataset
        """
        features, labels, tfidf_filename = self.TF_IDF_Vectorization()

        X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.25, random_state=0, stratify=labels)

        clf2 = RandomForestClassifier(random_state=1)
        clf4 = LogisticRegression(random_state=0)
        clf6 = CalibratedClassifierCV(LinearSVC())
        vot_clf = VotingClassifier(estimators = [('LinearSVC', clf6), ('RandomForest', clf2), ('LogisticRegression', clf4)], voting = 'soft')

        # cv = RepeatedKFold(n_splits=5, n_repeats=3, random_state=1)

        # scores = np.average(cross_val_score(vot_clf, X_train, y_train, scoring='accuracy', cv=cv, n_jobs=-1))

        vot_clf.fit(X_train, y_train)

        train_pred = vot_clf.predict(X_train)
        y_pred = vot_clf.predict(X_test)

        score=accuracy_score(y_test, y_pred)
        print('score======>',round(score,2))

        #print(metrics.classification_report(y_train, train_pred, target_names=self.dataset["PROBLEM_CATEGORY_DESC"].unique()))

        # Declaring the File Name
        # model_filename = os.path.join(self.model_path, "Ensembled_Model" + str(datetime.now().strftime("%Y_%m_%d_%H_%M_%S")) + ".pickle")
        model_filename = os.path.join(self.model_path, "Ensembled_Model.pickle")

        # Creating and Saving the pickle file for future useage
        with open(model_filename, 'wb') as file:
            pickle.dump(vot_clf, file)
            
        return score, tfidf_filename, model_filename


if __name__ == '__main__':

    # Reading the dataset
    dataset_path = r"C:\Users\ernpsaa\Desktop\WIP\Du Dubai\my_trial\codes\phase-2\nlp\Data\data-Triplets\output.xlsx"
    df = pd.read_excel(dataset_path, engine='openpyxl')
    
    counts = df['RESOLUTION_TYPE'].value_counts()

    df = df[~df['RESOLUTION_TYPE'].isin(counts[counts < 60].index)]
    
    # Provide the input variable
    features = ["Action",'Description','PRODUCT_TYPE']  
    # Provide the Target variable 
    target = "RESOLUTION_TYPE"

    # Path to save pickle files
    modelpath = r"C:\Users\ernpsaa\Desktop\WIP\Du Dubai\my_trial\codes\phase-2\nlp\Data\code\model_dump"
    TFIDF_path = r"C:\Users\ernpsaa\Desktop\WIP\Du Dubai\my_trial\codes\phase-2\nlp\Data\code\model_dump"
    
    # Creating the Object of class
    model_instance = EnsembleVotedModel(df, features, target, modelpath, TFIDF_path)
    scores, tfidf_filename, model_filename = model_instance.Modelt_Training()
    print("Model created Successfully!!!")
    print("tfidf_filename",tfidf_filename)
    print("model_filename",model_filename)
    print("Accuracy",scores)
    
    
# def test(text):
#     '''
#         test the model deployed for the text given
#         :param text: text given to test the model
#         :return: taxonomy of the text with its confidence percentage
#     '''
#     logging.info("-----------------------------in test------------------------------------")
    
#     try:
#         result = Email_Classification_Test_Script.testing_script(text)
#         return result
#     except Exception as e:
#         logging.error(e)