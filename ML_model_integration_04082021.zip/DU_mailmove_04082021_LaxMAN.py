
# =============================================================================
# # importing the libraries
# =============================================================================

import win32com.client
from win32com.client import Dispatch
import itertools
import re
import ctypes
import pythoncom
import time
import psutil
#from sr_data_proess import process_email
from exceptional_email import check_exceptional_email

import webbrowser
import os
import exchangelib 
from exchangelib import Folder
import traceback
import string
import random
import math
import numpy as np
import json
import requests
import configparser
from random import randint
# import psycopg2
# from psycopg2 import sql
import datetime
import os
import subprocess

from datetime import datetime

from time_calculator import *

from Ml_model_pred import predict_email_category

# =============================================================================
# # code to remove the signatures from the email
# =============================================================================

def remove_signature(message):
    string = " ".join(str(message).split())
    if 'Thank' in string:
        return(string.split('Thank')[0])
    elif 'thank' in string:
        return(string.split('thank')[0])
    elif 'Best Regard' in string:
        return(string.split('Best Regard')[0])
    elif 'Best regard' in string:
        return(string.split('Best regard')[0])
    elif 'Regard' in string:
        return(string.split('Regard')[0])
    elif 'regard' in string:
        return(string.split('regard')[0])
    else:
        return(message)




# =============================================================================
# API for SLAstatus
# =============================================================================

import requests
def ticketsla(ticket):
    url = "http://localhost:8008/slastatus/"+ticket
    mess = requests.get(url)
    return mess.json()
# ticket = "SD5899775"



# =============================================================================
# #check ticket validity based on ticket number
# =============================================================================


import re
# ticket=0
def check_valid_ticket(body):
    # Valid Reg
    regex1 = r'\w[IM|RD][0-9]{7}'       
    regex2 = r'\d+[-][A-Za-z0-9]{12}'    
    regexList = [regex1, regex2]
    
    # Checking reg value in body of Email
    found_regex_list=[]
    for x in regexList:
        some_list = re.findall(x,body)
        if some_list:
            found_regex_list.append(some_list)
    if len(found_regex_list)>0:
        #print('ticket No: ',found_regex_list)
        # global ticket
        ticket = found_regex_list[0]
        #jasonform('ticket',ticket)
        return 'valid', ticket
    else:    
        return 'invalid'
    
# print('Ticket no=======', ticket)

# =============================================================================
# #movement of email in diff folders
# =============================================================================

lis=[]
def move_email(session,email,message,body):
    subject= str(message.Subject)
    #ticket_list = ['IM5934728' , 'SD2412468' ,'1-237558170341']
    mail_stats = check_valid_ticket(body)
    category = predict_email_category(body)
    
    if check_exceptional_email(email) is True:
        print('This email is Present is Exceptional Email list and is directly moved to actionable folder')
        folder_name = 'Actionable'
        to_folder = session.Folders['santosh.prakash@ericsson.com'].Folders[folder_name]        
        message.Move(to_folder)
        print('Mail is moved to {}'.format(folder_name))
        send_replymail(email,message,'Exceptional',subject)
    
    elif mail_stats[0] == 'valid' and category != 'Other Issue':
        ticket=mail_stats[1] 
        mess = ticketsla(ticket[0])
        if mess!=False:
            
            date3 = SLA_target(mess[0]['date_time'],mess[0]['SLA_Hours'])
            
            present_date=datetime.now()
            
            remaining_time = get_hours(present_date,date3)
            
            print('Remaining time======',remaining_time)
            
            if remaining_time > 1 and mess[0]['Status']!='Resolved':
                print('Your ticket is under SLA')
                folder_name = 'IT-Under-SLA'
                to_folder = session.Folders['santosh.prakash@ericsson.com'].Folders[folder_name]        
                message.Move(to_folder)
                print('Mail is moved to {}'.format(folder_name))
                send_replymail(email,message,'under_SLA',subject)
            elif remaining_time > 1 and mess[0]['Status']=='Resolved':
                print('Your ticket is already resolved')
                folder_name = 'Non-Actionable'
                to_folder = session.Folders['santosh.prakash@ericsson.com'].Folders[folder_name]        
                message.Move(to_folder)
                print('Mail is moved to {}'.format(folder_name))
                send_replymail(email,message,'resolved',subject)
            elif  0< remaining_time <=1 and mess[0]['Status']!='Resolved':
                print('Your ticket is about to breach')
                folder_name = 'Non-Actionable'
                to_folder = session.Folders['santosh.prakash@ericsson.com'].Folders[folder_name]        
                message.Move(to_folder)
                print('Mail is moved to {}'.format(folder_name))
                send_replymail(email,message,'about_to_breach',subject)  
            elif  remaining_time <= 0 and mess[0]['Status']!='Resolved':
            #elif  remaining_time == 'Time already elapsed' and mess[0]['Status']!='Resolved':
                print('Your ticket is already breached')
                folder_name = 'Actionable'
                to_folder = session.Folders['santosh.prakash@ericsson.com'].Folders[folder_name]        
                message.Move(to_folder)
                print('Mail is moved to {}'.format(folder_name))
                send_replymail(email,message,'already_breached',subject) 
        else:
            print('It is not a valid Ticket!')
            folder_name = 'Non-Actionable'
            to_folder = session.Folders['santosh.prakash@ericsson.com'].Folders[folder_name]        
            message.Move(to_folder)
            print('Mail is moved to {}'.format(folder_name))
            send_replymail(email,message,mail_stats,subject)
      

    elif category == 'Other Issue':
        print('Other Issue!')
        folder_name = 'Non-Actionable'
        to_folder = session.Folders['santosh.prakash@ericsson.com'].Folders[folder_name]        
        message.Move(to_folder)
        print('Mail is moved to {}'.format(folder_name))
        #send_replymail(email,message,mail_stats,subject)
      

# =============================================================================
# #sending autoreply
# =============================================================================
def send_replymail(email,message,mail_stats,subject):    
    print("toaddress: ",email)
    o = win32com.client.Dispatch("Outlook.Application")
    Msg = o.CreateItem(0)
    Msg.To = email
    Msg.Subject = "DU IT Team - "+subject
    if mail_stats[0] == 'valid':
        Msg.HTMLBody = "<br>Dear " + str(message.Sender.Name).split()[0] + ',<br><br>' + "Your request is received and forwarded to the concerned team.<br>We will get back with the status of your request.<br><br>Warm Regards,<br>DU Service Desk"
    elif mail_stats=='under_SLA':
        Msg.HTMLBody = "<br>Dear " + str(message.Sender.Name).split()[0] + ',<br><br>' + "Your request is Under SLA. already team started working on it.<br>We will get back with the status of your request.<br><br>Warm Regards,<br>DU Service Desk" 
    elif mail_stats=='resolved':
        Msg.HTMLBody = "<br>Dear " + str(message.Sender.Name).split()[0] + ',<br><br>' + "Your ticket is already resolved.<br>Warm Regards,<br>DU Service Desk" 
    elif mail_stats=='about_to_breach':
        Msg.HTMLBody = "<br>Dear " + str(message.Sender.Name).split()[0] + ',<br><br>' + "(to be adressed to L1 engineer) This is to notify you that Your ticket is about to breach .<br>Warm Regards,<br>DU Service Desk" 
    elif mail_stats=='already_breached':
        Msg.HTMLBody = "<br>Dear " + str(message.Sender.Name).split()[0] + ',<br><br>' + "(to be adressed to L1 engineer) This is to notify that Your ticket has already  breached .<br>Warm Regards,<br>DU Service Desk" 
    elif mail_stats=='Exceptional':
        Msg.HTMLBody = "<br>Dear " + str(message.Sender.Name).split()[0] + ',<br><br>' + "Thankyou for your mail.Your request is received and forwarded to the concerned team.<br>We will get back with the status of your request.<br><br>Warm Regards,<br>DU Service Desk"    
    else:
        Msg.HTMLBody = "<br>Dear " + str(message.Sender.Name).split()[0] + ',<br><br>' + "Your Ticket number is missing or is Invalid. please resend the mail with a valid ticket number.<br><br>Warm Regards,<br>DU Service Desk"
    Msg.Send()
    print('Message Send Successfully!')


# =============================================================================
# #processes the email 
# =============================================================================
def start_email_processing(message):
    try:
        if message.SenderEmailType == 'EX':
            email = str(message.Sender.GetExchangeUser().PrimarySmtpAddress)
            print('EX')
        else:
            email = str(message.SenderEmailAddress)
        print(email)
        if any(x in email for x in
               ["@ericsson.com", "@eal-net.com"]):
            # print("clear")
            # print('message.To: name==== ',message.To)
            if "Santosh Prakash" in str(message.To):
                print("clear too")
                message.UnRead = False
                # body = " ".join(message.Body.split())
                body = remove_signature(message.Body)
                subject= str(message.Subject)
                text = subject + " " + body
                name = message.To
                print("subject:",subject)
                print("text:",text)

        return email, body 
    except Exception as e:
        print(e)


# =============================================================================
# #moving email
# =============================================================================


class Handler_Class(object):

    def OnQuit(self):
        ctypes.windll.user32.PostQuitMessage(0)

    def OnItemAdd(self, item):
        print("checking")
        if item.Class == 43:
            mail = item
            subject = mail.Subject
            
            print ("\nNew Mail : " + subject)   
            try: 
                print('Its working')
                email, body = start_email_processing(mail)
                session = initial_outlook_setup()
                session = session[1]
                move_email(session,email,mail,body)
                #send_replymail(email)           
            except Exception as ex:
                print('End:%s'%ex)
                pass

# =============================================================================
# #check if outlook is open and if not open it
# =============================================================================


def check_outlook_open():
    print("in check_outlook_open")
    list_process = []
    for pid in psutil.pids():
        p = psutil.Process(pid)
        list_process.append(p.name())
    if 'OUTLOOK.EXE' in list_process:
        print("OUTLOOK.EXE in list_process")
        return True
    else:
        # print("OUTLOOK.EXE not in list_process")
        subprocess.Popen([r"C:\Program Files (x86)\Microsoft Office\root\Office16\OUTLOOK.EXE"])
        return False

# =============================================================================
# #outlook setup and folders creation
# =============================================================================

def initial_outlook_setup():
    print("in initial_outlook_setup")
    try:
        outlook_open = check_outlook_open()
        print("outlook_open: ", outlook_open)
    except Exception as e:
        print("error= ", e)
        outlook_open = False
        print("outlook_open: ", outlook_open)
    if outlook_open == True:
        session = win32com.client.Dispatch("Outlook.Application").Session
        user = session.CreateRecipient("santosh.prakash@ericsson.com")
                
        # Outlook folders
        root_folder = session.Folders['santosh.prakash@ericsson.com']

        print('root_folder: ',root_folder)
        
        folder_list = []
        for folder in root_folder.Folders:
            folder_list.append(folder.Name)
        #print(folder_list)
        # Create folders
        if 'Non-Actionable' not in folder_list:
            root_folder.Folders.Add("Non-Actionable")
            print("Non-Actionable folder is created!")
        if 'IT-Under-SLA' not in folder_list:
            root_folder.Folders.Add("IT-Under-SLA")
            print("IT-Under-SLA folder is created!")
        if 'Actionable' not in folder_list:
            root_folder.Folders.Add("Actionable")
            print("Actionable folder is created!")
        return session.GetSharedDefaultFolder(user, 6).Items, session
    return None



# =============================================================================
# #bot that keeps checking new mail
# =============================================================================
def future_email_mode():
    print("in future_email_mode")
    pythoncom.CoInitialize()
    while True:
        print("------------------------------------------------------------")
        shared_inbox = initial_outlook_setup()
        shared_inbox = shared_inbox[0]
        if shared_inbox is not None:
            outlook = win32com.client.DispatchWithEvents(shared_inbox, Handler_Class)
            pythoncom.PumpWaitingMessages()
            print("pump wait msgs")
            print("outlook: ", outlook)
        time.sleep(20)

future_email_mode()
