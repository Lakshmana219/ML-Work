import psycopg2
from psycopg2 import sql
import yaml
import datetime
import logging

import pickle
import math
from nltk.stem import WordNetLemmatizer
import nltk
from nltk.corpus import wordnet
from nltk.stem.snowball import EnglishStemmer
import re

# logging.basicConfig(filename='RPA_Server_simulator_log.txt', level=logging.DEBUG,
#                     format='%(asctime)s - %(levelname)s - %(message)s', filemode= "a")

# with open('database.yaml', 'r') as stream:
#     input = yaml.safe_load(stream)

# user = input['db_web_api']['user']
# password = input['db_web_api']['password']
# host = input['db_web_api']['host']
# port = input['db_web_api']['port']
# database = input['db_web_api']['database']

# def db_connection():
#     '''
#         Establishes postgreSQL DB connection
#         :return: connection object
#     '''
#     try:
#         connection = psycopg2.connect(user=user,
#                                       password=password,
#                                       host=host,
#                                       port=port,
#                                       database=database)
#         logging.info("connection established")
#         return connection
#     except (Exception, psycopg2.Error) as e:
#         logging.error("Error while connecting to PostgreSQL: ", e)
#         return e

# def connection_close(connection):
#     '''
#         closes the DB connection
#         :param connection: connection object established
#     '''
#     try:
#         logging.info("in connection close")
#         connection.close()
#     except Exception as e:
#         logging.error("Error while closing postgresql: ", e)
# '''
# msg_body, msg_subject, "to", cc, date_time, 
# "Problem_Type", "SLA_Hours", "Ticket_Number", 
# "Assigned_Engineer", msg_id, verified_date_time, 
# "Status"
# '''

def predict_email_category(email):
    #print('script calling')
    #print('sentence:',email)
    issue_type_model = pickle.load(open(r"model_cts_email.pickle", 'rb'))
    issue_type_tfidf = pickle.load(open(r"tfidf_cts_email.pkl", 'rb'))
    text = [email]
    #print('script called')
    text_features = issue_type_tfidf.transform(text)
    #print('features done')
    issue_type = issue_type_model.predict(text_features.toarray())
    #print('prediction done')
    prediction_prob = issue_type_model.predict_proba(text_features.toarray())
    #print('lets see')
    # predictions_prob = loaded_model.predict(text_features)
    confidence_issue_type = math.ceil(prediction_prob.max() * 100)
    #print('Category:',issue_type[0])
    #print('confidence_issue_type:',confidence_issue_type)
    return issue_type[0]

# def problem_type_sla_hours(category):
#     logging.info("-----------------------------In RPA SLA Data Server Mail------------------------------------")
#     try:
#         connection = db_connection()
#         if connection:
#             query = sql.SQL('''
#                             select "PT_id", "ProblemType", sla_id, "AE_id" from "Problem_Type" 
#                             where "ProblemType" = %s
#                         ''')
#             cursor = connection.cursor()
#             cursor.execute(query, (category,))
#             records = cursor.fetchall()
#             each_rec = {}
#             all_rec = []
#             if len(records)>0:
#                 each_rec["PT_id"] = records[0][0]
#                 each_rec["ProblemType"] = records[0][1]
#                 each_rec["sla_id"] = records[0][2]
#                 each_rec["AE_id"] = records[0][3]
#                 all_rec.append(each_rec)
#                 #each_rec={}
#             connection_close(connection)
#             return all_rec[0]
#     except Exception as e:
#         logging.error(e)

# def ticket_creation():
#     logging.info("-----------------------------In Ticket Creation------------------------------------")
#     try:
#         connection = db_connection()
#         if connection:
#             cursor = connection.cursor()
#             query = '''select "Ticket_Number", "Modified_Date" from sla_table order by "Modified_Date" DESC limit 1'''
#             cursor.execute(query)
#             record = cursor.fetchall()
#             all_rec=[]
#             if len(record)>0:
#                 Ticket_Number = record[0][0]
#                 #each_rec['Modified_Date'] = record[0][1]
#                 regex1 = r'[0-9]{7}'
#                 numb = re.findall(regex1,Ticket_Number)[0]
#                 numb = numb + 1 
#             else:
#                 return 'No records found!'
#         connection_close(connection)
#         return all_rec
#     except Exception as e:
#         logging.error(e)

# def sla_server_mail(msg_body,msg_subject,to, SLA_Hours_id, Ticket_Number, Problem_Type_id, AE_id):
#     print(msg_body,msg_subject,to, SLA_Hours_id, Ticket_Number, Problem_Type_id, AE_id)
#     logging.info("-----------------------------In RPA SLA Data Server Mail------------------------------------")
#     time_now = datetime.datetime.now()
#     Status = 'Not resolved'    
#     try:
#         connection = db_connection()
#         #{'PT_id': 1, 'ProblemType': 'Bill Not Available', 'sla_id': 1, 'AE_id': 1}
#         if connection:
#             query = '''insert into sla_table (msg_body, msg_subject, "to", date_time, "SLA_Hours_id", "Ticket_Number", "Status", "Problem_Type_id", "AE_id", "Modified_Date")\
#                  values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)'''
#             cursor = connection.cursor()
#             cursor.execute(query, (msg_body, msg_subject, to, time_now, SLA_Hours_id, Ticket_Number, Status, Problem_Type_id, AE_id, time_now,))
#             connection.commit()
#             msg = "RPA SLA Email inserted successfully"
#             return msg
#         else:
#             return 'Please check You DB connection!'
#     except Exception as e:
#         logging.error(e)